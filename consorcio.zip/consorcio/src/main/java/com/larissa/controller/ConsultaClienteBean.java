package com.larissa.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.larissa.model.Cliente;
import com.larissa.util.JpaUtil;

@ManagedBean(name="consultaClientebean")
@ViewScoped
public class ConsultaClienteBean implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	private List<Cliente> clientes;
	
	public void consultar() {
	EntityManager manager = JpaUtil.getEntityManager();
	  TypedQuery<Cliente> query = manager.createQuery
			  ("from Cliente", Cliente.class);
	  
			this.clientes = query.getResultList();
			manager.close();
			}
			public List<Cliente> getClientes() {
			return clientes;
			}
			
}


