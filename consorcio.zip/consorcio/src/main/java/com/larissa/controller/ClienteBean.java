package com.larissa.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import com.larissa.model.Cliente;

@ManagedBean (name="clienteBean")
public class ClienteBean  implements Serializable {
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Cliente> clientes;
	   private Cliente novoCliente;

	   public ClienteBean(){
		   this.clientes = new ArrayList<>();
		   this.novoCliente = new Cliente();
	   }
	   
	   public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void adicionar() {
		   this.clientes.add(this.novoCliente);
		   this.novoCliente = new Cliente();
		   }
		   public List<Cliente> getCliente() {
		   return clientes;
		   }
		   public void setClientes(List<Cliente> clientes) {
		   this.clientes = clientes;
		   }
		   public Cliente getNovoCliente() {
		   return novoCliente;
		   }
		   }
		
