package com.larissa.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "veiculo")
public class Veiculo extends Produto{
	
	


	private String modelo;
	private String placa;
	private String cor;
	private String chassi;
	private String cilindros;
	
	
	public Veiculo() {
	
		super();
		// TODO Auto-generated constructor stub
	}



	public Veiculo( String unidade, String descricao, Date dataCadastro, Integer estoque, float valor,
			String modelo, String placa, String cor, String chassi, String cilindros) {
		super(unidade, descricao, dataCadastro, estoque, valor);		this.modelo = modelo;
		this.placa = placa;
		this.cor = cor;
		this.chassi = chassi;
		this.cilindros = cilindros;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((chassi == null) ? 0 : chassi.hashCode());
		result = prime * result + ((placa == null) ? 0 : placa.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Veiculo other = (Veiculo) obj;
		if (chassi == null) {
			if (other.chassi != null)
				return false;
		} else if (!chassi.equals(other.chassi))
			return false;
		if (placa == null) {
			if (other.placa != null)
				return false;
		} else if (!placa.equals(other.placa))
			return false;
		return true;
	}

	
	public String getModelo() {
		return modelo;
	}



	public void setModelo(String modelo) {
		this.modelo = modelo;
	}



	public String getPlaca() {
		return placa;
	}



	public void setPlaca(String placa) {
		this.placa = placa;
	}



	public String getCor() {
		return cor;
	}



	public void setCor(String cor) {
		this.cor = cor;
	}



	public String getChassi() {
		return chassi;
	}



	public void setChassi(String chassi) {
		this.chassi = chassi;
	}



	public String getCilindros() {
		return cilindros;
	}



	public void setCilindros(String cilindros) {
		this.cilindros = cilindros;
	}
	
	
	
	
}
